/*
 * Hello World Reloaded
 * 9/21/17
 * @author Aviel Resnick
 */

public class HelloWorld {
	   public static void main(String [] args) {
		      System.out.println("                 d         ");
		      System.out.println("          o     l          ");
		      System.out.println("         l     r           ");
		      System.out.println("          l     o          ");
		      System.out.println("         e     W           ");
		      System.out.println("        H                  ");
		      System.out.println("    xxxxxxxxxxxxxxxxx      ");
		      System.out.println("    x            x   x     ");
		      System.out.println("    x    Java    x   x     ");
		      System.out.println("    x            xxxx      ");
		      System.out.println("    x   is hot!  x         ");
		      System.out.println("    x            x         ");
		      System.out.println("    x            x         ");
		      System.out.println("    xxxxxxxxxxxxxx         ");
		   }
}
