/*
 * Project 2-1
 * 10/1/2017
 * Displays your name, address, and telephone number.
 * @author Aviel Resnick
 */

public class project2_1 {
	public static void main(String [] args) {
		// Prints info
		System.out.println("Aviel Resnick \n123 Road Road \n123-123-1234");
	}
}
