/*
 * Project 2-2
 * 10/1/2017
 * Prints a yield sign
 * @author Aviel Resnick
 */
public class project2_2 {
	public static void main(String[] args) {
		// Prints out a yield sign
        System.out.println("      *");
        System.out.println("     * *");
        System.out.println("    *   *");
        System.out.println("   *     *");
        System.out.println("  * Yield *");
        System.out.println(" *         *");
        System.out.println("*************");
    }
}
