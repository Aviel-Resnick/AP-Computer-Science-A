public class YorkshireTerrier extends Dog  // concrete classes as well as
                                    // abstract classes can be extended by
                                    // another class
{
  private String whereFrom;

  public YorkshireTerrier (String dogName, int weight)
  {
    super (dogName,weight);
  }

  public void setPlace(String location)
  {
    whereFrom = location;
  }

  public String speak()  // overwrites speak in Dog
  {
    // This is on purpose, my yorkie produces a sound which
    // resembels a meow.
    return  "Meow";
  }

  public String move()  // overwrites move in Dog
  {
    return  "Mighty Miniture Leaps";
  }

  public String cityOfOrigin()
  {
    return whereFrom;
  }

}
