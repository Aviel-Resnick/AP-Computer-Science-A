/*
  Aviel Resnick
   Test the summation class
   Week 24
   AP Comp Sci
*/

import java.util.*;

public class Tester {
    public static void main(String[] args) {
        Summation sum = new Summation(3,5);
        System.out.println(sum);
    }
}
